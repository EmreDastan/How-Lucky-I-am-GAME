package derspackage;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class DersClass {
	public static void main(String[] args) throws IOException {
		for (int i = 0; i < 10; i++) {
			int luck = 100 - i*10;
			int lives = 10 - i - 1;
			
		System.out.println("Try to guess the number between 1 and 10, 1 and 10 are included.");
		Random random = new Random();
		int r = random.nextInt(10);
		int numbers[] = {1,2,3,4,5,6,7,8,9,10};
		Scanner scan = new Scanner(System.in);
		int guess = scan.nextInt();
		if (guess == numbers[r]) {
			System.out.println("CORRECT !\nYOU WIN !");
			System.out.println("The number was : " + numbers[r]);
			System.out.println("YOUR LUCK IS : " + luck + "%");
			break;
		}
		else {
			System.out.println("WRONG !");
			System.out.println("TRY AGAIN !");
			System.out.println("The number was : " + numbers[r]);
			System.out.println("You have " + lives + " lives left.");
			if (i == 9) {
				System.out.println("YOU LOST !\nYou only have 10 lives.");
				System.out.println("YOUR LUCK IS : %0");
			}
		}
		}
		FileWriter writer = new FileWriter("C:\\Users\\PC\\Documents\\Java Projects\\HowLuckyIAmGAME\\README.txt");
		writer.write("This program is created by Yunus Emre Dastan.\nTook a few minutes to write right after learning how to use \"random\".");
		writer.close();
	}
	
}